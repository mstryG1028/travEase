import recommendationService from "../recommendation.service.js";

const recommendationTool = {
  name: "recommendation",

  description:
    "Finds the top 3 most relevant listings based on the user's natural language requirements.",

  async execute({ question, user }) {
    return await recommendationService.getRecommendations({
      question,
      user,
    });
  },
};

export default recommendationTool;
