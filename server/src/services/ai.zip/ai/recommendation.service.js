class RecommendationService {
  async getRecommendations({ question, user }) {
    console.log("Recommendation Request:", question);

    return {
      success: true,
      message: "Recommendation service is working.",
      data: [],
    };
  }
}

export default new RecommendationService();
